################################################################################
# Script 4: LDA Topic Modeling and Sentiment Analysis on Bundestag Abortion Debates
# Author: Lara Türmer
################################################################################

# Load required libraries
library(quanteda)
library(quanteda.textmodels)
library(quanteda.textstats)
library(quanteda.textplots)
library(topicmodels)
library(tidyverse)
library(reticulate)
library(udpipe)

# Set working directory
setwd("/Users/laratuermer/Documents/Studies/Master/WiSe 2425/Quantitative Textanalysis/TermpaperQTA/Sources/bundestag_xml_20wp")

################################################################################
# 1. Load preprocessed data and model
################################################################################
df_rede_218 <- readRDS("df_rede_218.rds")
ud_model <- udpipe_download_model(language = "german", model_dir = "models/")
ud_model <- udpipe_load_model(file = ud_model$file_model)

################################################################################
# 2. POS-tagging and lemmatization (only NOUNs)
################################################################################
anno <- udpipe_annotate(ud_model, x = df_rede_218$Text_Corpus, doc_id = df_rede_218$Speech_ID)
anno_df <- as.data.frame(anno)

nouns_only <- anno_df %>%
  filter(upos == "NOUN") %>%
  select(doc_id, lemma)

nouns_grouped <- nouns_only %>%
  group_by(doc_id) %>%
  summarise(text_nouns = paste(lemma, collapse = " ")) %>%
  left_join(df_rede_218 %>% select(Speech_ID, Party), by = c("doc_id" = "Speech_ID"))

################################################################################
# 3. Create corpus and Document-Feature Matrix (DFM)
################################################################################
corp_nouns <- corpus(nouns_grouped, text_field = "text_nouns")
docvars(corp_nouns, "Party") <- nouns_grouped$Party

toks_nouns <- tokens(corp_nouns) %>%
  tokens_remove(pattern = parliament_stopwords)

dfm_nouns <- dfm(toks_nouns) %>%
  dfm_trim(min_termfreq = 5)

################################################################################
# 4. LDA Topic Modeling (k = 5)
################################################################################
dtm_nouns <- convert(dfm_nouns, to = "topicmodels")
lda_model_nouns <- LDA(dtm_nouns, k = 5, method = "Gibbs", control = list(seed = 1234))

topics_nouns <- topics(lda_model_nouns)
nouns_grouped$Topic_LDA_NOUNS <- as.factor(topics_nouns)

saveRDS(lda_model_nouns, "lda_model_nouns.rds")
saveRDS(nouns_grouped, "df_nouns_topics.rds")

terms(lda_model_nouns, 10)

################################################################################
# 5. Topic Distribution by Party (absolute and relative)
################################################################################
topic_party_counts <- nouns_grouped %>%
  filter(!is.na(Topic_LDA_NOUNS)) %>%
  count(Party, Topic_LDA_NOUNS)

# Absolute plot
ggplot(topic_party_counts, aes(x = Party, y = n, fill = Party)) +
  geom_col(position = "dodge", color = "white", width = 0.7) +
  facet_wrap(~ Topic_LDA_NOUNS, scales = "free_y") +
  scale_fill_manual(values = party_colors) +
  labs(title = "Number of Speeches per Topic and Party", x = "Party", y = "Count", fill = "Party") +
  theme_minimal(base_size = 14) +
  theme(plot.title = element_text(face = "bold"),
        axis.text.x = element_text(angle = 30, hjust = 1),
        legend.position = "right")

ggsave("topic_party_distribution_absolute.png", width = 10, height = 6, dpi = 300)

# Relative plot
topic_party_relative <- topic_party_counts %>%
  group_by(Topic_LDA_NOUNS) %>%
  mutate(Relative = n / sum(n)) %>%
  ungroup()

ggplot(topic_party_relative, aes(x = Party, y = Relative, fill = Party)) +
  geom_col(position = "dodge", color = "white", width = 0.7) +
  facet_wrap(~ Topic_LDA_NOUNS, scales = "free_y") +
  scale_fill_manual(values = party_colors) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  labs(title = "Relative Share of Speeches by Party per Topic", x = "Party", y = "Share", fill = "Party") +
  theme_minimal(base_size = 14) +
  theme(plot.title = element_text(face = "bold"),
        axis.text.x = element_text(angle = 30, hjust = 1),
        legend.position = "none")

ggsave("topic_party_distribution_relative.png", width = 10, height = 6, dpi = 300)

# Gray version for publication
ggplot(topic_party_relative, aes(x = Party, y = Relative, fill = "gray")) +
  geom_col(position = "dodge", color = "white", width = 0.7) +
  facet_wrap(~ Topic_LDA_NOUNS, scales = "free_y") +
  scale_fill_manual(values = c("gray" = "#A9A9A9"), guide = "none") +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  labs(title = "Relative Share of Speeches per Topic and Party", x = "Party", y = "Share of Topic (in %)") +
  theme_minimal(base_size = 14) +
  theme(plot.title = element_text(face = "bold"),
        axis.text.x = element_text(angle = 30, hjust = 1))

ggsave("topic_party_distribution_relative_gray.png", width = 10, height = 6, dpi = 300)

################################################################################
# 6. Sentiment by Topic and Party
################################################################################
sentiment_df <- readRDS("sentiment_by_chunk.rds") %>%
  rename(Sentiment = Label)

df_topics_nouns_sentiment <- nouns_grouped %>%
  left_join(sentiment_df %>% select(Speech_ID, Sentiment, Score), by = c("doc_id" = "Speech_ID"))

sentiment_summary_nouns <- df_topics_nouns_sentiment %>%
  filter(!is.na(Topic_LDA_NOUNS)) %>%
  group_by(Party, Topic_LDA_NOUNS, Sentiment) %>%
  summarise(Count = n(), .groups = "drop") %>%
  group_by(Party, Topic_LDA_NOUNS) %>%
  mutate(Proportion = Count / sum(Count))

ggplot(sentiment_summary_nouns, aes(x = Party, y = Proportion, fill = Sentiment)) +
  geom_bar(stat = "identity", position = "stack", color = "white", width = 0.7) +
  facet_wrap(~ Topic_LDA_NOUNS, scales = "free_y") +
  scale_fill_manual(values = c("positive" = "#F4A300", "neutral" = "#046c7c", "negative" = "#C14000")) +
  labs(title = "Sentiment by Topic and Party (Noun-based)", x = "Party", y = "Proportion", fill = "Sentiment") +
  theme_minimal(base_size = 14) +
  theme(plot.title = element_text(face = "bold"),
        axis.text.x = element_text(angle = 30, hjust = 1),
        legend.position = "right")

ggsave("sentiment_by_topic_party_nouns.png", width = 10, height = 6, dpi = 300)

################################################################################
# 7. Perplexity Plot to Determine Optimal k
################################################################################
k_values <- 2:10
perplexities <- numeric(length(k_values))

for (i in seq_along(k_values)) {
  model <- LDA(dtm_nouns, k = k_values[i], method = "Gibbs", control = list(seed = 1234))
  perplexities[i] <- perplexity(model, dtm_nouns)
}

df_perplexity <- data.frame(k = k_values, perplexity = perplexities)

ggplot(df_perplexity, aes(x = k, y = perplexity)) +
  geom_line(color = "steelblue") +
  geom_point(color = "steelblue", size = 2) +
  labs(title = "Perplexity by Number of Topics", x = "Number of Topics (k)", y = "Perplexity") +
  theme_minimal()

ggsave("perplexity_by_k.png", width = 7, height = 5, dpi = 300)

################################################################################
# 8. Table: Top Terms per Topic
################################################################################
top_terms <- list(
  `Topic 1` = c("recht", "kind", "kinder", "unterstützung", "fall", "schutz", "leb", "familie", "zeit", "problem"),
  `Topic 2` = c("§", "information", "selbstbestimmung", "regelung", "abtreibung", "kommission", "beratung", "werbung", "streichung", "mehrheit"),
  `Topic 3` = c("jahr", "fraktion", "antrag", "koalition", "punkt", "union", "politik", "ampelkoalition", "debatte", "verantwortung"),
  `Topic 4` = c("entscheidung", "jahren", "thema", "situation", "fragen", "schluß", "widerspruchslösung", "leb", "monat", "gesetzentwurf"),
  `Topic 5` = c("frauen", "lieb", "fraktion", "tagen", "seit", "welt", "kampf", "beispiel", "länder", "bildung")
)

topic_labels <- c(
  "Topic 1" = "Life, Children & Support",
  "Topic 2" = "Legal Regulation & Autonomy",
  "Topic 3" = "Parliamentary Politics",
  "Topic 4" = "Decision-Making & Reform",
  "Topic 5" = "Gender, Culture & Society"
)

topic_table <- tibble(
  Topic = names(top_terms),
  `Topic Label` = topic_labels[names(top_terms)],
  `Top Terms` = sapply(top_terms, function(words) paste(words, collapse = ", "))
)

topic_table %>%
  kable("html", caption = "LDA Topics: Descriptions and Top Terms") %>%
  kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive"), full_width = FALSE)

save_kable(
  topic_table %>%
    kable("html", caption = "LDA Topics: Descriptions and Top Terms") %>%
    kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive"), full_width = FALSE),
  file = "lda_topics_updated.html"
)

pagedown::chrome_print("lda_topics_updated.html", output = "lda_topics.pdf")
